package org.magnum.mobilecloud.video.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class ResourceBadRequestException extends RuntimeException {
	
	/**
	 * Generated serial ID
	 */
	private static final long serialVersionUID = 3874582169052404153L;

	public ResourceBadRequestException() {
		this("Bad request when access the resource.");
	}

	public ResourceBadRequestException(String message) {
		this(message, null);
	}

	public ResourceBadRequestException(String message, Throwable cause) {
		super(message, cause);
	}

}
