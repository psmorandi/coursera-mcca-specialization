package com.psmorandi.coursera.assignment3.webapi;

import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.psmorandi.coursera.assignment3.LoginActivity;
import com.psmorandi.coursera.assignment3.https.UnsafeHttpsClient;
import com.psmorandi.coursera.assignment3.oauth.SecuredRestBuilder;

import retrofit.RestAdapter;
import retrofit.client.OkClient;

/**
 * Created by Paulo on 24/08/2015.
 */
public class VideoService {

    private static final String CLIENT_ID = "mobile";

    private static VideoSvcApi videoSvcApi;

    public static synchronized VideoSvcApi get(Context context) {
        if (videoSvcApi == null) {
            Intent intent = new Intent(context, LoginActivity.class);
            context.startActivity(intent);
        }
        return videoSvcApi;
    }

    public static synchronized VideoSvcApi init(String server, String user,
                                                String pass) {

        String tokenPath = server + VideoSvcApi.TOKEN_PATH;

        Log.d("VDO_SERVICE", "OAUTH URL: " + tokenPath);

        videoSvcApi = new SecuredRestBuilder()
                .setLoginEndpoint(tokenPath)
                .setUsername(user)
                .setPassword(pass)
                .setClientId(CLIENT_ID)
                .setClient(
                        new OkClient(UnsafeHttpsClient.getUnsafeOkHttpClient()))
                .setEndpoint(server).setLogLevel(RestAdapter.LogLevel.FULL).build()
                .create(VideoSvcApi.class);

        return videoSvcApi;
    }
}
