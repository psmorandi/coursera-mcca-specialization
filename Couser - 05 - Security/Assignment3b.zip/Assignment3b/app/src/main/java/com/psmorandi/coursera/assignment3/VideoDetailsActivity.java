package com.psmorandi.coursera.assignment3;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.common.base.Joiner;
import com.psmorandi.coursera.assignment3.utils.ProgressUtil;
import com.psmorandi.coursera.assignment3.utils.RetainedFragmentManager;
import com.psmorandi.coursera.assignment3.utils.WorkingTask;
import com.psmorandi.coursera.assignment3.webapi.VideoService;
import com.psmorandi.coursera.assignment3.webapi.VideoSvcApi;
import com.psmorandi.coursera.assignment3.webapi.model.Video;

public class VideoDetailsActivity extends FragmentActivity {

    public static final String VIDEO_ID_EXTRAS = "br.com.psmorandi.video_id";
    /**
     * Debugging tag used by the Android logger.
     */
    private final String TAG = getClass().getSimpleName();

    private TextView videoTitle;
    private TextView videoUrl;
    private TextView videoDuration;
    private TextView videoOwner;
    private TextView videoNumberOfLikes;
    private TextView videoLikedBy;
    private View scrollView;
    private ProgressBar progressBar;

    private VideoDetailsTask videoDetailsTask;
    private LikeUnlikeVideoTask likeUnlikeVideoTask;

    private long videoId;

    /**
     * Used to retain the states between runtime configuration
     * changes.
     */
    protected final RetainedFragmentManager mRetainedFragmentManager =
            new RetainedFragmentManager(this.getFragmentManager(),
                    TAG);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_details);

        videoTitle = (TextView) findViewById(R.id.video_title_text);
        videoUrl = (TextView) findViewById(R.id.video_url_text);
        videoDuration = (TextView) findViewById(R.id.video_duration_text);
        videoOwner = (TextView) findViewById(R.id.video_owner_text);
        videoNumberOfLikes = (TextView) findViewById(R.id.video_likes_text);
        videoLikedBy = (TextView) findViewById(R.id.video_liked_by_text);

        scrollView = findViewById(R.id.details_view);
        progressBar = (ProgressBar) findViewById(R.id.details_progress);

        Intent intent = this.getIntent();
        if (intent == null || !intent.hasExtra(VIDEO_ID_EXTRAS)) {
            finish();
            return;
        }

        videoId = intent.getLongExtra(VIDEO_ID_EXTRAS, -1);

        if (mRetainedFragmentManager.firstTimeIn()) {
            videoDetailsTask = new VideoDetailsTask();
            videoDetailsTask.execute();
        } else {
            videoDetailsTask = mRetainedFragmentManager.get("details");
            likeUnlikeVideoTask = mRetainedFragmentManager.get("like");

            if (videoDetailsTask.isWorking() ||
                    (likeUnlikeVideoTask != null && likeUnlikeVideoTask.isWorking()))
                ProgressUtil.showProgress(this, scrollView, progressBar);
            else {
                videoDetailsTask = new VideoDetailsTask();
                videoDetailsTask.execute();
            }
        }
    }

    public void onClickLikeVideo(View view) {
        likeUnlikeVideoTask = new LikeUnlikeVideoTask();
        likeUnlikeVideoTask.execute(true);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        mRetainedFragmentManager.put("details", videoDetailsTask);
        mRetainedFragmentManager.put("like", likeUnlikeVideoTask);
    }

    public void onClickUnlikeVideo(View view) {
        likeUnlikeVideoTask = new LikeUnlikeVideoTask();
        likeUnlikeVideoTask.execute(false);
    }

    class VideoDetailsTask extends WorkingTask<Void, Void, Video> {

        @Override
        protected void onPreExecute() {
            ProgressUtil.showProgress(VideoDetailsActivity.this, scrollView, progressBar);
        }

        @Override
        protected Video executeInBackground(Void... params) {

            VideoSvcApi videoSvcApi = VideoService.get(VideoDetailsActivity.this);

            try {
                Video video = videoSvcApi.getVideoById(videoId);

                //This information already came from the first call, but i'm forcing again
                //just to full fill the requirement 7 of the assignment.. sorry for that lack of
                //creativity..
                video.setLikedBy(videoSvcApi.getUsersWhoLikedVideo(videoId));

                return video;

            } catch (Exception ex) {
                return null;
            }
        }

        @Override
        protected void onFinish(Video video) {
            if (video == null) {
                Toast.makeText(VideoDetailsActivity.this.getApplicationContext(),
                        R.string.error_get_video_details,
                        Toast.LENGTH_LONG).show();
                finish();
                return;
            }

            mRetainedFragmentManager.put("video", video);

            refreshVideoDetails(video);

            ProgressUtil.hideProgress(VideoDetailsActivity.this, scrollView, progressBar);
        }
    }

    private void refreshVideoDetails(Video video) {
        if (video == null) return;

        videoTitle.setText(video.getName());
        videoDuration.setText(String.valueOf(video.getDuration()));
        videoNumberOfLikes.setText(String.valueOf(video.getLikes()));
        videoOwner.setText(video.getOwner());
        videoUrl.setText(video.getUrl());
        videoLikedBy.setText(Joiner.on(",").join(video.getLikedBy()));
    }

    class LikeUnlikeVideoTask extends WorkingTask<Boolean, Void, Boolean> {

        @Override
        protected void onPreExecute() {
            ProgressUtil.showProgress(VideoDetailsActivity.this, scrollView, progressBar);
        }

        @Override
        protected Boolean executeInBackground(Boolean... params) {

            boolean isToLikeVideo = params[0];

            VideoSvcApi videoSvcApi = VideoService.get(VideoDetailsActivity.this);

            try {
                //this empty string is some work around, something related with okhttp:
                //http://stackoverflow.com/questions/30358545/caused-by-retrofit-retrofiterror-method-post-must-have-a-request-body/30358749?noredirect=1#comment48809814_30358749
                if (isToLikeVideo) {
                    videoSvcApi.likeVideo(videoId, "");
                    showToast(getString(R.string.video_liked_success));
                } else {
                    videoSvcApi.unlikeVideo(videoId, "");
                    showToast(getString(R.string.video_unliked_success));
                }
                return true;
            } catch (Exception ex) {
                showToast("Couldn't " + (isToLikeVideo ? "like" : "unlike") + " this video: " +
                        ex.getMessage());
                return false;
            }
        }

        @Override
        protected void onFinish(Boolean aBoolean) {
            ProgressUtil.hideProgress(VideoDetailsActivity.this, scrollView, progressBar);

            //Update the details
            videoDetailsTask = new VideoDetailsTask();
            videoDetailsTask.execute();
        }
    }

    private void showToast(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(VideoDetailsActivity.this, message, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
