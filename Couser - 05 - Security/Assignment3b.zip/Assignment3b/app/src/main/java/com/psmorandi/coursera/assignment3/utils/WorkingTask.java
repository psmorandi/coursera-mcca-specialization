package com.psmorandi.coursera.assignment3.utils;

import android.os.AsyncTask;

public abstract class WorkingTask<Params, Progress, Result> extends AsyncTask<Params, Progress, Result> {
    private volatile boolean isWorking = false;

    protected abstract Result executeInBackground(Params... params);

    protected abstract void onFinish(Result result);

    @Override
    protected Result doInBackground(Params... params) {
        isWorking = true;
        return executeInBackground(params);
    }

    @Override
    protected void onPostExecute(Result result) {
        isWorking = false;
        onFinish(result);
    }

    public boolean isWorking() {
        return isWorking;
    }
}
