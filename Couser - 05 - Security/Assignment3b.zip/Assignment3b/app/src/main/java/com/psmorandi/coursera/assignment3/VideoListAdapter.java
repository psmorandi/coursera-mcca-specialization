package com.psmorandi.coursera.assignment3;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.common.collect.Lists;
import com.psmorandi.coursera.assignment3.webapi.model.Video;

import java.util.Collection;
import java.util.List;

/**
 * Created by sergio on 26/08/2015.
 */
public class VideoListAdapter extends RecyclerView.Adapter<VideoListAdapter.VideoViewHolder> {

    private List<Video> mVideosDataSet;

    public VideoListAdapter(List<Video> videos) {
        mVideosDataSet = videos;
    }

    // Create new views (invoked by the layout manager)
    @Override
    public VideoListAdapter.VideoViewHolder onCreateViewHolder(ViewGroup parent,
                                                               int viewType) {
        // create a new view
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.video_item, parent, false);

        // set the view's size, margins, padding and layout parameters
        return new VideoViewHolder(v);
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(VideoViewHolder holder, int position) {
        // - get element from your data set at this position
        // - replace the contents of the view with that element
        View view = holder.mView;
        Video video = mVideosDataSet.get(position);

        TextView videoTitle = (TextView) view.findViewById(R.id.videoTitleTextView);
        TextView likes = (TextView) view.findViewById(R.id.likesTextView);

        videoTitle.setText(video.getName());
        likes.setText("Number of likes: " + video.getLikes());

    }

    public void setVideosDataSet(Collection<Video> videosDataSet) {
        mVideosDataSet = Lists.newArrayList(videosDataSet);
        this.notifyDataSetChanged();
    }

    // Return the size of your data set (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return mVideosDataSet.size();
    }

    @Override
    public long getItemId(int position) {
        return mVideosDataSet.get(position).getId();
    }

    // Provide a reference to the views for each data item
    // Complex data items may need more than one view per item, and
    // you provide access to all the views for a data item in a view holder
    public static class VideoViewHolder extends RecyclerView.ViewHolder {
        // each data item is just a string in this case
        public View mView;

        public VideoViewHolder(View v) {
            super(v);
            mView = v;
        }
    }
}
