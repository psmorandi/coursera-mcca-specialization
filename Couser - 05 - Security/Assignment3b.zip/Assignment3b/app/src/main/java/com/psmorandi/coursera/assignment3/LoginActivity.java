package com.psmorandi.coursera.assignment3;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.psmorandi.coursera.assignment3.utils.ProgressUtil;
import com.psmorandi.coursera.assignment3.utils.RetainedFragmentManager;
import com.psmorandi.coursera.assignment3.utils.WorkingTask;
import com.psmorandi.coursera.assignment3.webapi.VideoService;
import com.psmorandi.coursera.assignment3.webapi.VideoSvcApi;

/**
 * A login screen that offers login via email/password.
 */
public class LoginActivity extends FragmentActivity {

    /**
     * Keep track of the login task to ensure we can cancel it if requested.
     */
    private UserLoginTask mAuthTask = null;

    /**
     * Debugging tag used by the Android logger.
     */
    private final String TAG = getClass().getSimpleName();


    // UI references.
    private AutoCompleteTextView mUserNameView;
    private EditText mPasswordView;
    private ProgressBar mProgressView;
    private View mLoginFormView;
    private EditText mServerView;
    private Button mEmailSignInButton;

    /**
     * Used to retain the states between runtime configuration
     * changes.
     */
    protected final RetainedFragmentManager mRetainedFragmentManager =
            new RetainedFragmentManager(this.getFragmentManager(),
                    TAG);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Set up the login form.
        mUserNameView = (AutoCompleteTextView) findViewById(R.id.username);

        mPasswordView = (EditText) findViewById(R.id.password);
        mPasswordView.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int id, KeyEvent keyEvent) {
                if (id == R.id.login || id == EditorInfo.IME_NULL) {
                    attemptLogin();
                    return true;
                }
                return false;
            }
        });

        mServerView = (EditText) findViewById(R.id.server);

        mEmailSignInButton = (Button) findViewById(R.id.sign_in_button);
        mEmailSignInButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                attemptLogin();
            }
        });

        mLoginFormView = findViewById(R.id.login_form);
        mProgressView = (ProgressBar) findViewById(R.id.login_progress);

        // find the retained fragment on activity restarts
        if (!mRetainedFragmentManager.firstTimeIn()) {
            mAuthTask = mRetainedFragmentManager.get("data");
            if (mAuthTask != null && mAuthTask.isWorking()) {
                ProgressUtil.showProgress(this, mLoginFormView, mProgressView);
            } else {
                ProgressUtil.hideProgress(this, mLoginFormView, mProgressView);
            }
        }
    }

    @Override
    public void onBackPressed() {
        //do nothing...
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        // store the data in the fragment
        mRetainedFragmentManager.put("data", mAuthTask);
    }

    /**
     * Attempts to sign in or register the account specified by the login form.
     * If there are form errors (invalid email, missing fields, etc.), the
     * errors are presented and no actual login attempt is made.
     */
    public void attemptLogin() {
        if (mAuthTask != null && mAuthTask.isWorking()) {
            return;
        }

        // Reset errors.
        mUserNameView.setError(null);
        mPasswordView.setError(null);

        // Store values at the time of the login attempt.
        String userName = mUserNameView.getText().toString();
        String password = mPasswordView.getText().toString();
        String server = mServerView.getText().toString();

/*        String userName = "user3";
        String password = "pass";
        String server = "https://note-dell-i7:8443";*/

        boolean cancel = false;
        View focusView = null;

        // Check for a valid userName address.
        if (TextUtils.isEmpty(userName)) {
            mUserNameView.setError(getString(R.string.error_field_required));
            focusView = mUserNameView;
            cancel = true;
        }

        if (TextUtils.isEmpty(server)) {
            mServerView.setError(getString(R.string.error_field_required));
            focusView = mServerView;
            cancel = true;
        }

        if (cancel) {
            // There was an error; don't attempt login and focus the first
            // form field with an error.
            focusView.requestFocus();
        } else {
            // Show a progress spinner, and kick off a background task to
            // perform the user login attempt.
            ProgressUtil.showProgress(this, mLoginFormView, mProgressView);
            mAuthTask = new UserLoginTask(server, userName, password);
            mAuthTask.execute((Void) null);
        }
    }

    /**
     * Represents an asynchronous login/registration task used to authenticate
     * the user.
     */
    public class UserLoginTask extends WorkingTask<Void, Void, Boolean> {

        private final String mUserName;
        private final String mPassword;
        private final String mServer;

        UserLoginTask(String server, String userName, String password) {
            mUserName = userName;
            mPassword = password;
            mServer = server;
        }

        @Override
        protected Boolean executeInBackground(Void... params) {

            VideoSvcApi videoSvcApi = VideoService.init(mServer, mUserName, mPassword);

            try {
                videoSvcApi.getVideoList();
            } catch (Exception ex) {
                Log.w(TAG, "Error when getting video list: ", ex);
                return false;
            }

            return true;
        }

        @Override
        protected void onFinish(final Boolean success) {
            resetAuthTask();
            ProgressUtil.hideProgress(LoginActivity.this, mLoginFormView, mProgressView);

            if (success) {
                finish();
            } else {
                mEmailSignInButton.requestFocus();
            }
        }
    }

    private void resetAuthTask() {
        mAuthTask = null;
        mRetainedFragmentManager.put("data", null);
    }
}

