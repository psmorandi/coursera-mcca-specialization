package com.psmorandi.coursera.assignment3;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.psmorandi.coursera.assignment3.utils.RecyclerItemClickListener;
import com.psmorandi.coursera.assignment3.webapi.VideoService;
import com.psmorandi.coursera.assignment3.webapi.VideoSvcApi;
import com.psmorandi.coursera.assignment3.webapi.model.Video;

import java.util.ArrayList;
import java.util.Collection;

public class MainActivity extends AppCompatActivity {

    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    private SwipeRefreshLayout mSwipeRefreshLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mRecyclerView = (RecyclerView) findViewById(R.id.listRecyclerView);

        // use this setting to improve performance if you know that changes
        // in content do not change the layout size of the RecyclerView
        mRecyclerView.setHasFixedSize(true);

        // use a linear layout manager
        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);

        // specify an adapter (see also next example)
        mAdapter = new VideoListAdapter(new ArrayList<Video>());
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.addOnItemTouchListener(
                new RecyclerItemClickListener(this, new RecyclerItemClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        long videoId = mAdapter.getItemId(position);
                        Intent intent = new Intent(MainActivity.this, VideoDetailsActivity.class);
                        intent.putExtra(VideoDetailsActivity.VIDEO_ID_EXTRAS, videoId);
                        startActivity(intent);
                    }
                }));

        mSwipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipeRefreshLayout);
        mSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                if (mSwipeRefreshLayout.isRefreshing()) {
                    mSwipeRefreshLayout.setRefreshing(false);
                }
                //Refreshing data on server
                refreshVideos();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if (id == R.id.action_add_video_metadata) {
            Intent intent = new Intent(this, NewVideoMetadataActivity.class);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();

        refreshVideos();
    }

    private void refreshVideos() {
        VideoSvcApi videoSvcApi = VideoService.get(this);
        if (videoSvcApi == null) {
            return;
        }

        new GetVideoListTask().execute();
    }

    class GetVideoListTask extends AsyncTask<Void, Void, Collection<Video>> {

        @Override
        protected Collection<Video> doInBackground(Void... params) {

            VideoSvcApi videoSvcApi = VideoService.get(MainActivity.this);

            try {
                return videoSvcApi.getVideoList();
            } catch (Exception ex) {
                return null;
            }
        }

        @Override
        protected void onPostExecute(Collection<Video> videos) {
            ((VideoListAdapter) mAdapter).setVideosDataSet(videos == null ? new ArrayList<Video>() : videos);

            if (mSwipeRefreshLayout.isRefreshing()) {
                mSwipeRefreshLayout.setRefreshing(false);
            }
        }
    }
}
