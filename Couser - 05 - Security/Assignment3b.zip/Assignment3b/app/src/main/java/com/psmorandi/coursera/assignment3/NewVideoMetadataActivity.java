package com.psmorandi.coursera.assignment3;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.psmorandi.coursera.assignment3.utils.ProgressUtil;
import com.psmorandi.coursera.assignment3.utils.RetainedFragmentManager;
import com.psmorandi.coursera.assignment3.utils.WorkingTask;
import com.psmorandi.coursera.assignment3.webapi.VideoService;
import com.psmorandi.coursera.assignment3.webapi.VideoSvcApi;
import com.psmorandi.coursera.assignment3.webapi.model.Video;

public class NewVideoMetadataActivity extends FragmentActivity {

    /**
     * Debugging tag used by the Android logger.
     */
    private final String TAG = getClass().getSimpleName();
    /**
     * Used to retain the states between runtime configuration
     * changes.
     */
    protected final RetainedFragmentManager mRetainedFragmentManager =
            new RetainedFragmentManager(this.getFragmentManager(),
                    TAG);

    private TextView videoTitleTextView;
    private TextView videoUrlTextView;
    private TextView videoDurationTextView;

    private View videoFormView;
    private ProgressBar progressBar;

    private SaveVideoMetadataTask saveVideoMetadataTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_video_metadata);

        videoTitleTextView = (TextView) findViewById(R.id.new_video_title_text);
        videoDurationTextView = (TextView) findViewById(R.id.new_video_duration_text);
        videoUrlTextView = (TextView) findViewById(R.id.new_video_url_text);

        videoFormView = findViewById(R.id.new_video_form);
        progressBar = (ProgressBar) findViewById(R.id.new_video_progress);

        if(!mRetainedFragmentManager.firstTimeIn()){
            saveVideoMetadataTask = mRetainedFragmentManager.get("task");
            if(saveVideoMetadataTask != null && saveVideoMetadataTask.isWorking()){
                ProgressUtil.showProgress(NewVideoMetadataActivity.this, videoFormView, progressBar);
            } else {
                ProgressUtil.hideProgress(NewVideoMetadataActivity.this, videoFormView, progressBar);
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        mRetainedFragmentManager.put("task", saveVideoMetadataTask);
    }

    public void onClickAddVideo(View view) {
        videoDurationTextView.setError(null);
        videoTitleTextView.setError(null);
        videoUrlTextView.setError(null);

        String videoTitle = videoTitleTextView.getText().toString();
        String videoUrl = videoUrlTextView.getText().toString();
        String videoDurationAsString = videoDurationTextView.getText().toString();
        long videoDuration = -1;

        boolean cancel = false;
        View focusView = null;

        if (TextUtils.isEmpty(videoTitle)) {
            videoTitleTextView.setError(getString(R.string.error_field_required));
            cancel = true;
            focusView = videoTitleTextView;
        } else if (TextUtils.isEmpty(videoUrl)) {
            videoUrlTextView.setError(getString(R.string.error_field_required));
            cancel = true;
            focusView = videoUrlTextView;
        } else if (TextUtils.isEmpty(videoDurationAsString)) {
            videoDurationTextView.setError(getString(R.string.error_field_required));
            cancel = true;
            focusView = videoDurationTextView;
        } else {
            if (!Patterns.WEB_URL.matcher(videoUrl).matches()) {
                videoUrlTextView.setError(getString(R.string.error_field_invalid_url));
                cancel = true;
                focusView = videoUrlTextView;
            } else {
                videoDuration = Long.valueOf(videoDurationAsString);
                if (videoDuration <= 0) {
                    videoDurationTextView.setError(getString(R.string.error_field_greater_than_zero));
                    cancel = true;
                    focusView = videoDurationTextView;
                }
            }
        }

        if (cancel) {
            // There was an error; don't attempt login and focus the first
            // form field with an error.
            focusView.requestFocus();
        } else {
            saveVideoMetadataTask = new SaveVideoMetadataTask();
            saveVideoMetadataTask.execute(new Video(videoTitle, videoUrl, videoDuration, 0));
        }
    }

    class SaveVideoMetadataTask extends WorkingTask<Video, Void, Video> {

        @Override
        protected void onPreExecute() {
            ProgressUtil.showProgress(NewVideoMetadataActivity.this, videoFormView, progressBar);
        }

        @Override
        protected Video executeInBackground(Video... params) {
            VideoSvcApi videoSvcApi = VideoService.get(NewVideoMetadataActivity.this);

            try {
                Thread.sleep(8*1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            try {
                return videoSvcApi.addVideo(params[0]);
            } catch (Exception ex) {
                showToast("Error adding video metadata: " + ex.getMessage());
                return null;
            }
        }

        @Override
        protected void onFinish(Video video) {
            ProgressUtil.hideProgress(NewVideoMetadataActivity.this, videoFormView, progressBar);

            if (video == null) return;

            showToast(getString(R.string.add_video_success));

            finish();
        }
    }

    private void showToast(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(NewVideoMetadataActivity.this, message, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
