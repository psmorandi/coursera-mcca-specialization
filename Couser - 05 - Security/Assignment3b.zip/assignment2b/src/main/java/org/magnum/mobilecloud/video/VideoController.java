package org.magnum.mobilecloud.video;

import java.security.Principal;
import java.util.Collection;

import javax.servlet.http.HttpServletResponse;

import org.magnum.mobilecloud.video.client.VideoSvcApi;
import org.magnum.mobilecloud.video.exceptions.ResourceAccessDeniedException;
import org.magnum.mobilecloud.video.exceptions.ResourceBadRequestException;
import org.magnum.mobilecloud.video.repository.Video;
import org.magnum.mobilecloud.video.repository.VideoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Lists;

@Controller
public class VideoController {

	@Autowired
	private VideoRepository videoRepository;

	@RequestMapping(VideoSvcApi.VIDEO_SVC_PATH)
	public @ResponseBody Collection<Video> getVideos() {
		return Lists.newArrayList(videoRepository.findAll());
	}

	@RequestMapping(VideoSvcApi.VIDEO_SVC_PATH + "/{id}")
	public @ResponseBody Video getVideoById(@PathVariable("id") long videoId) {
		return findVideoById(videoId);
	}

	@RequestMapping(value = VideoSvcApi.VIDEO_SVC_PATH, method = RequestMethod.POST)
	public @ResponseBody Video saveVideo(@RequestBody Video video, Principal principal) {

		video.setOwner(principal.getName());

		Collection<Video> videosWithSameName = videoRepository.findByName(video.getName());

		for (Video videoWithSameName : videosWithSameName) {
			// If already have the same video and it not belongs to the user...
			if (videoWithSameName.equals(video) && !videoWithSameName.getOwner().equals(video.getOwner())) {
				String message = String.format("Can't save video with name %s. Already belongs to another user.",
						video.getName());
				throw new ResourceAccessDeniedException(message);
			}
		}

		return videoRepository.save(video);
	}

	@RequestMapping(value = VideoSvcApi.VIDEO_SVC_PATH + "/{id}/like", method = RequestMethod.POST)
	public void likeVideo(@PathVariable("id") long videoId, HttpServletResponse response, Principal principal) {

		Video video = findVideoById(videoId);

		String user = principal.getName();

		if (hasUserLikedVideo(user, video))
			throw new ResourceBadRequestException(
					"User already liked this video. Only one like per video is permitted.");

		// everything seems to be ok, go ahead and like the video..
		video.likeVideo(user);

		videoRepository.save(video);

		// Set response, since we have 'void' as return (discussed here
		// https://class.coursera.org/mobilecloudsecurity-001/forum/thread?thread_id=184)
		response.setStatus(HttpServletResponse.SC_OK);
	}

	@RequestMapping(value = VideoSvcApi.VIDEO_SVC_PATH + "/{id}/unlike", method = RequestMethod.POST)
	public void unlikeVideo(@PathVariable("id") long videoId, HttpServletResponse response, Principal principal) {

		Video video = findVideoById(videoId);

		String user = principal.getName();

		if (!hasUserLikedVideo(user, video))
			throw new ResourceBadRequestException(
					"User did not liked this video before. Can only unlike previously liked video.");

		video.unlikeVideo(user);

		videoRepository.save(video);

		// Set response, since we have 'void' as return (discussed here
		// https://class.coursera.org/mobilecloudsecurity-001/forum/thread?thread_id=184)
		response.setStatus(HttpServletResponse.SC_OK);
	}

	@RequestMapping(VideoSvcApi.VIDEO_SVC_PATH + "/{id}/likedby")
	public @ResponseBody Collection<String> getUsersWhoLikedVideo(@PathVariable("id") long videoId) {
		Video video = findVideoById(videoId);
		return video.getLikedBy();
	}

	/**
	 * Returns a video with the given Id. If no video is found, an exception is
	 * thrown.
	 * 
	 * @param id
	 *            Video id
	 * @return Found video;
	 */
	private Video findVideoById(long id) {
		Video video = videoRepository.findOne(Long.valueOf(id));

		if (video == null)
			throw new ResourceNotFoundException();

		return video;
	}

	/**
	 * If user had liked the video before, then true is return, false otherwise.
	 * 
	 * @param video
	 *            Video retrieved from the data base.
	 * @param authorizedUserName
	 *            The user name that was authorized
	 * 
	 */
	private boolean hasUserLikedVideo(String authorizedUserName, Video video) {
		// this is the easiest way to implement, but probably not very
		// efficient..
		for (String userName : video.getLikedBy()) {
			if (userName.equals(authorizedUserName))
				return true;
		}

		return false;
	}
}