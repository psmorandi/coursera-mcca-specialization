package org.magnum.mobilecloud.video.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.FORBIDDEN)
public class ResourceAccessDeniedException extends RuntimeException {

	/**
	 * Generated serial ID
	 */
	private static final long serialVersionUID = 8741009868742388703L;
	
	public ResourceAccessDeniedException() {
		this("Access denied for the resource!");
	}

	public ResourceAccessDeniedException(String message) {
		this(message, null);
	}

	public ResourceAccessDeniedException(String message, Throwable cause) {
		super(message, cause);
	}

}
