package org.magnum.dataup.operation;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

import javax.servlet.http.HttpServletResponse;

import org.magnum.dataup.VideoFileManager;
import org.magnum.dataup.model.Video;
import org.magnum.dataup.model.VideoStatus;
import org.magnum.dataup.model.VideoStatus.VideoState;
import org.magnum.dataup.utils.ControllerUtils;
import org.springframework.web.multipart.MultipartFile;

public class VideoOperations {
	private static final AtomicLong currentId = new AtomicLong(0L);

	private Map<Long, Video> videos = new HashMap<Long, Video>();

	public Collection<Video> getAllVideos() {
		return videos.values();
	}

	public Video getVideoById(long videoId) {
		return videos.get(videoId);
	}

	public boolean copyVideoDataIfAvailable(Video video,
			HttpServletResponse response) {
		try {
			if (VideoFileManager.get().hasVideoData(video)) {
				VideoFileManager.get().copyVideoData(video,
						response.getOutputStream());

				return true;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		return false;
	}

	public Video saveVideoMetadata(Video video) {
		video = checkAndSetId(video);
		long id = video.getId();
		video.setDataUrl(getDataUrl(id));
		videos.put(id, video);

		return video;
	}

	public VideoStatus saveVideoData(Video video, MultipartFile videoData) {
		InputStream videoDataStream;
		try {
			videoDataStream = videoData.getInputStream();
			VideoFileManager.get().saveVideoData(video, videoDataStream);

			return new VideoStatus(VideoState.READY);
		} catch (IOException e) {
			e.printStackTrace();
		}

		return null;
	}

	private Video checkAndSetId(Video video) {
		if (video.getId() == 0) {
			video.setId(currentId.incrementAndGet());
		}

		return video;
	}

	private String getDataUrl(long videoId) {
		String url = ControllerUtils.getUrlBaseForLocalServer() + "/video/"
				+ videoId + "/data";
		return url;
	}

}
