package org.magnum.dataup;

import java.util.Collection;

import javax.servlet.http.HttpServletResponse;

import org.magnum.dataup.model.Video;
import org.magnum.dataup.model.VideoStatus;
import org.magnum.dataup.operation.VideoOperations;
import org.magnum.dataup.utils.ControllerUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class VideoController {

	private VideoOperations videoOps = new VideoOperations();

	@RequestMapping("/video")
	public @ResponseBody Collection<Video> getVideoList() {
		return videoOps.getAllVideos();
	}

	@RequestMapping("/video/{id}/data")
	public void getData(@PathVariable("id") long id,
			HttpServletResponse response) {
		Video video = videoOps.getVideoById(id);

		if (video == null) {
			ControllerUtils.sendNotFoundToClient(response, "Video not found.");
			return;
		}

		if (!videoOps.copyVideoDataIfAvailable(video, response)) {
			ControllerUtils.sendNotFoundToClient(response, "Video not found.");
		}
	}

	@RequestMapping(value = "/video", method = RequestMethod.POST)
	public @ResponseBody Video addVideo(@RequestBody Video video) {

		Video savedVideo = videoOps.saveVideoMetadata(video);

		return savedVideo;
	}

	@RequestMapping(value = "/video/{id}/data", method = RequestMethod.POST)
	public @ResponseBody VideoStatus setVideoData(@PathVariable("id") long id,
			@RequestParam("data") MultipartFile videoData,
			HttpServletResponse response) {

		Video video = videoOps.getVideoById(id);
		if (video == null) {
			ControllerUtils.sendNotFoundToClient(response, "Video not found.");
			return null;
		}

		VideoStatus status = videoOps.saveVideoData(video, videoData);

		if (status == null) {
			ControllerUtils.sendInternalServerErrorToClient(response,
					"Something went wrong. Please try again.");
		}

		return status;
	}
}