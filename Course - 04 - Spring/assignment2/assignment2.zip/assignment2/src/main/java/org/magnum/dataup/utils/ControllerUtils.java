package org.magnum.dataup.utils;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

public class ControllerUtils {

	public static void sendNotFoundToClient(HttpServletResponse response,
			String extraMessage) {
		sendErrorToClient(response, HttpStatus.NOT_FOUND, extraMessage);
	}

	public static void sendInternalServerErrorToClient(
			HttpServletResponse response, String extraMessage) {
		sendErrorToClient(response, HttpStatus.INTERNAL_SERVER_ERROR,
				extraMessage);
	}

	public static void sendErrorToClient(HttpServletResponse response,
			HttpStatus error, String extraMessage) {
		try {
			response.sendError(error.value(), extraMessage);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static String getUrlBaseForLocalServer() {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder
				.getRequestAttributes()).getRequest();
		String base = "http://"
				+ request.getServerName()
				+ ((request.getServerPort() != 80) ? ":"
						+ request.getServerPort() : "");
		return base;
	}

}
