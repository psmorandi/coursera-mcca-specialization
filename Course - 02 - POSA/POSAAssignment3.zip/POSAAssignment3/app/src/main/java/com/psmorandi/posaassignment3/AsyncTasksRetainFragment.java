package com.psmorandi.posaassignment3;

import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;

import java.lang.ref.WeakReference;

/**
 * Class responsible to retain some data across change in the Activity configuration, as suggested
 * in http://www.androiddesignpatterns.com/2013/04/retaining-objects-across-config-changes.html
 *
 * @author Paulo (21/04/2015).
 */
public class AsyncTasksRetainFragment extends Fragment {

    public static final String FILE_URL_ARGUMENT = "com.psmorandi.FILE_TO_DOWNLOAD";
    /**
     * Debugging tag used by the Android logger.
     */
    private final String TAG = getClass().getSimpleName();
    private String mStatusLabelText;

    /**
     * This is the callback called by the Download manager activity
     */
    interface ImageProcessCallback {

        /**
         * Called when the file was successfully downloaded
         */
        void onDownloadSuccess();

        /**
         * Called when the gray scale has finished his processing.
         *
         * @param uri The path to the gray scale file.
         */
        void onGrayScaleProcessSuccess(Uri uri);

        /**
         * Called when something went wrong with the file processing.
         */
        void onError();
    }

    /**
     * Stores the callback to the activity
     */
    private ImageProcessCallback mImageProcessCallback;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Retain this fragment across configuration changes.
        setRetainInstance(true);

        //get the uri for the file to be downloaded as string from the arguments
        Bundle arguments = getArguments();
        Uri fileToDownload = Uri.parse(arguments.getString(FILE_URL_ARGUMENT));

        Log.d(TAG, "onCreate()");
        Log.d(TAG, "File to download: " + fileToDownload.toString());

        //Starts the download now
        new DownloadImageAsync(this.getActivity()).execute(fileToDownload);
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        //After the fragment is attached to the activity, we get the callback to the activity.
        mImageProcessCallback = (ImageProcessCallback) activity;

        Log.d(TAG, "onAttach()");
    }

    @Override
    public void onDetach() {
        super.onDetach();
        //After the fragment is detached from the activity, we set null to the callback, since there
        // is no one to callback.
        mImageProcessCallback = null;

        Log.d(TAG, "onDetach()");
    }

    /**
     * Sets the actual status label, to retain it across configuration changes.
     * @param text Status label
     */
    public void setStatusLabelText(String text) {
        mStatusLabelText = text;
    }

    /**
     * Gets the stored status label retained across configuration changes.
     * @return Status label retained.
     */
    public String getStatusLabelText() {
        return mStatusLabelText;
    }

    /**
     * Async task responsible to download the image.
     */
    class DownloadImageAsync extends AsyncTask<Uri, Void, Uri> {

        /**
         * Weak reference to the context
         */
        final WeakReference<Context> mContextReference;

        public DownloadImageAsync(Context context) {
            mContextReference = new WeakReference<>(context);
        }

        @Override
        protected Uri doInBackground(Uri... params) {

            Context context = mContextReference.get();
            if (context == null) {
                return null;
            }

            try {
                return Utils.downloadImage(context, params[0]);
            } catch (Exception ex) {
                Log.w(TAG, "Error while downloading the image: " + params[0], ex);
                return null;
            }
        }

        @Override
        protected void onPostExecute(Uri uri) {
            if (mImageProcessCallback != null) {
                if (uri != null) {
                    mImageProcessCallback.onDownloadSuccess();
                } else {
                    mImageProcessCallback.onError();
                    //should not continue if an error occurred
                    return;
                }
            }
            //After we successfully downloaded the file, we need to make it gray..
            //Remembering that this code is executed in the main thread..
            new GrayScaleProcessorAsync(mContextReference.get()).execute(uri);
        }
    }

    /**
     * Async task responsible to process the image transforming it in gray scale.
     */
    class GrayScaleProcessorAsync extends AsyncTask<Uri, Void, Uri> {
        private final WeakReference<Context> mContextWeakReference;

        public GrayScaleProcessorAsync(Context context) {
            mContextWeakReference = new WeakReference<>(context);
        }

        @Override
        protected Uri doInBackground(Uri... params) {
            Context context = mContextWeakReference.get();
            if (context == null) {
                return null;
            }

            try {
                return Utils.grayScaleFilter(context, params[0]);
            } catch (Exception ex) {
                Log.w(TAG, "Error while processing the image: " + params[0], ex);
                return null;
            }
        }

        @Override
        protected void onPostExecute(Uri uri) {
            if (mImageProcessCallback != null) {
                if (uri != null) {
                    mImageProcessCallback.onGrayScaleProcessSuccess(uri);
                } else {
                    mImageProcessCallback.onError();
                }
            }
        }
    }
}