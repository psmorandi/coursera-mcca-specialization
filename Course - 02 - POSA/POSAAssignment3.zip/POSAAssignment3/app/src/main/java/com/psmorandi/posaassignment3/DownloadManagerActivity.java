package com.psmorandi.posaassignment3;

import android.app.Activity;
import android.app.FragmentManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.TextView;

/**
 * Activity responsible to coordinate the image download and processing.
 * @author Paulo (18/04/2015).
 */
public class DownloadManagerActivity extends Activity implements AsyncTasksRetainFragment.ImageProcessCallback {

    /**
     * Extra results returned to the main activity
     */
    public static final String EXTRA_RESULT = "EXTRA_RESULT";

    private TextView mStatusLabel;

    /**
     * Identifier of the fragment retained.
     */
    private static final String TAG_TASK_FRAGMENT = "task_fragment";
    private AsyncTasksRetainFragment mTaskFragment;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_downloadmanager);

        Intent intent = getIntent();
        if (intent == null || intent.getData() == null) {
            finishActivityWithError("Invalid URL.");
            return;
        }

        mStatusLabel = (TextView) findViewById(R.id.statusLabel);

        FragmentManager fm = getFragmentManager();
        mTaskFragment = (AsyncTasksRetainFragment) fm.findFragmentByTag(TAG_TASK_FRAGMENT);

        // If the Fragment is non-null, then it is currently being
        // retained across a configuration change.
        // more info here: http://www.androiddesignpatterns.com/2013/04/retaining-objects-across-config-changes.html
        if (mTaskFragment == null) {

            Bundle arguments = new Bundle();
            arguments.putString(AsyncTasksRetainFragment.FILE_URL_ARGUMENT, intent.getData().toString());

            mTaskFragment = new AsyncTasksRetainFragment();
            mTaskFragment.setArguments(arguments);

            fm.beginTransaction().add(mTaskFragment, TAG_TASK_FRAGMENT).commit();

            mStatusLabel.setText("Downloading...");
        } else {
            //we came from a retained instance, so restore the label text...
            mStatusLabel.setText(mTaskFragment.getStatusLabelText());
        }
    }

    @Override
    public void onDownloadSuccess() {
        //Setting the next label..
        mStatusLabel.setText("Processing image...");
    }

    @Override
    public void onError() {
        finishActivityWithError("There was an error while processing the image.");
    }

    private void finishActivityWithError(String message) {
        Intent resultIntent = new Intent();
        //Extra info to the main activity
        resultIntent.putExtra(EXTRA_RESULT, message);
        setResult(RESULT_CANCELED, resultIntent);
        if (!this.isFinishing()) {
            finish();
        }
    }

    @Override
    public void onGrayScaleProcessSuccess(Uri uri) {
        Intent intent = new Intent();
        intent.setData(uri);
        setResult(RESULT_OK, intent);
        if (!this.isFinishing()) {
            finish();
        }
    }

    @Override
    protected void onDestroy() {
        //retaining the label text
        mTaskFragment.setStatusLabelText(mStatusLabel.getText().toString());
        super.onDestroy();
    }
}