package com.psmorandi.posaassignment3;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

/**
 * A simple activity to show the image.
 * @author Paulo (14/04/2015).
 */
public class ImageViewerActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent startIntent = getIntent();
        if (startIntent == null || startIntent.getData() == null) {
            Utils.showToast(this, "No image to display");
            finish();
            return;
        }

        setContentView(R.layout.activity_imageviewer);
        ImageView imageContainer = (ImageView) findViewById(R.id.imageContainer);
        imageContainer.setImageURI(startIntent.getData());
    }
}
