package com.psmorandi.posaassignment3;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.View;
import android.webkit.URLUtil;
import android.widget.TextView;


public class MainActivity extends ActionBarActivity {

    private Uri mDefaultURL = Uri.parse("http://www.dre.vanderbilt.edu/~schmidt/robot.png");
    private static final int DOWNLOAD_MANAGER_ACTIVITY = 1;
    /**
     * Debugging tag used by the Android logger.
     */
    private final String TAG = getClass().getSimpleName();
    private TextView mUrlTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mUrlTextView = (TextView) findViewById(R.id.urlTextView);
    }

    public void onProcessImageButtonClick(View view) {

        String url = mUrlTextView.getText().toString();

        Uri uri = (null != url && !url.equals(""))? Uri.parse(url) : mDefaultURL;

        if(!URLUtil.isValidUrl(uri.toString())){
            Utils.showToast(this,"Invalid URL. Please try again.");
            return;
        }

        Intent intent = new Intent(this, DownloadManagerActivity.class);
        intent.setData(uri);
        startActivityForResult(intent, DOWNLOAD_MANAGER_ACTIVITY);
    }

    /**
     * Hook method called back by the Android Activity framework when
     * an Activity that's been launched exits, giving the requestCode
     * it was started with, the resultCode it returned, and any
     * additional data from it.
     */
    @Override
    protected void onActivityResult(int requestCode,
                                    int resultCode,
                                    Intent data) {
        if (DOWNLOAD_MANAGER_ACTIVITY == requestCode) {
            if (Activity.RESULT_OK == resultCode) {
                //Everything was ok, so send the uri gray scale file address to the viewer activity.
                Intent intent = new Intent(this, ImageViewerActivity.class);
                intent.setData(data.getData());
                startActivity(intent);
            } else {
                if (data != null) {
                    Utils.showToast(this, data.getStringExtra(DownloadManagerActivity.EXTRA_RESULT));
                } else {
                    Utils.showToast(this, "There was an error while processing the image.");
                }
            }

        } else {
            Utils.showToast(this, "Unknown error.");
        }
    }

    /**
     * Hook method called after onCreate() or after onRestart() (when
     * the activity is being restarted from stopped state).  Should
     * re-acquire resources relinquished when activity was stopped
     * (onStop()) or acquire those resources for the first time after
     * onCreate().
     */
    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "onStart()");
    }

    /**
     * Hook method called after onRestoreStateInstance(Bundle) only if
     * there is a prior saved instance state in Bundle object.
     * onResume() is called immediately after onStart().  onResume()
     * is called when user resumes activity from paused state
     * (onPause()) User can begin interacting with activity.  Place to
     * start animations, acquire exclusive resources, such as the
     * camera.
     */
    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume()");
    }

    /**
     * Hook method called when an Activity loses focus but is still
     * visible in background. May be followed by onStop() or
     * onResume().  Delegate more CPU intensive operation to onStop
     * for seamless transition to next activity.  Save persistent
     * state (onSaveInstanceState()) in case app is killed.  Often
     * used to release exclusive resources.
     */
    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "onPause()");
    }

    /**
     * Called when Activity is no longer visible.  Release resources
     * that may cause memory leak. Save instance state
     * (onSaveInstanceState()) in case activity is killed.
     */
    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "onStop()");
    }

    /**
     * Hook method called when user restarts a stopped activity.  Is
     * followed by a call to onStart() and onResume().
     */
    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(TAG, "onRestart()");
    }

    /**
     * Hook method that gives a final chance to release resources and
     * stop spawned threads.  onDestroy() may not always be
     * called-when system kills hosting process
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy()");
    }
}
