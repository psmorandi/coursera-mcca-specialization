package com.psmorandi.weatherappassignment3.operations;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.RemoteException;
import android.util.Log;

import com.psmorandi.weatherappassignment3.MainActivity;
import com.psmorandi.weatherappassignment3.aidl.WeatherCall;
import com.psmorandi.weatherappassignment3.aidl.WeatherData2;
import com.psmorandi.weatherappassignment3.aidl.WeatherRequest;
import com.psmorandi.weatherappassignment3.aidl.WeatherResults;
import com.psmorandi.weatherappassignment3.services.WeatherServiceAsync;
import com.psmorandi.weatherappassignment3.services.WeatherServiceSync;
import com.psmorandi.weatherappassignment3.utils.GenericServiceConnection;
import com.psmorandi.weatherappassignment3.utils.Utils;

import java.lang.ref.WeakReference;
import java.util.List;

/**
 * @author Paulo (01/06/2015).
 */
public class WeatherServicesOpsImpl implements WeatherServicesOps {

    /**
     * Debugging tag used by the Android logger.
     */
    protected final String TAG = getClass().getSimpleName();
    /**
     * This Handler is used to post runnable to the UI from the
     * mWeatherResults callback methods to avoid a dependency on the
     * Activity, which may be destroyed in the UI Thread during a
     * runtime configuration change.
     */
    private final Handler mDisplayHandler = new Handler();
    /**
     * Used to enable garbage collection.
     */
    protected WeakReference<MainActivity> mActivity;
    private final WeatherResults.Stub mWeatherResults = new WeatherResults.Stub() {
        @Override
        public void sendResults(final List<WeatherData2> results) throws RemoteException {
            // Since the Android Binder framework dispatches this
            // method in a background Thread we need to explicitly
            // post a runnable containing the results to the UI
            // Thread, where it's displayed.  We use the
            // mDisplayHandler to avoid a dependency on the
            // Activity, which may be destroyed in the UI Thread
            // during a runtime configuration change.
            mDisplayHandler.post(new Runnable() {
                public void run() {
                    handleServiceResult(results);
                }
            });
        }
    };
    protected String mCityOrCountry;
    /**
     * This GenericServiceConnection is used to receive results after
     * binding to the AcronymServiceSync Service using bindService().
     */
    private GenericServiceConnection<WeatherCall> mServiceConnectionSync;
    /**
     * This GenericServiceConnection is used to receive results after
     * binding to the AcronymServiceAsync Service using bindService().
     */
    private GenericServiceConnection<WeatherRequest> mServiceConnectionAsync;

    public WeatherServicesOpsImpl(MainActivity activity) {
        mActivity = new WeakReference<>(activity);

        initializeNonViewFields();
    }

    /**
     * (Re)initialize the non-view fields (e.g.,
     * GenericServiceConnection objects).
     */
    private void initializeNonViewFields() {
        mServiceConnectionSync =
                new GenericServiceConnection<>
                        (WeatherCall.class);

        mServiceConnectionAsync =
                new GenericServiceConnection<>
                        (WeatherRequest.class);
    }

    @Override
    public void bindService() {
        Log.d(TAG,
                "calling bindService()");

        // Launch the Acronym Bound Services if they aren't already
        // running via a call to bindService(), which binds this
        // activity to the AcronymService* if they aren't already
        // bound.
        if (mServiceConnectionSync.getInterface() == null)
            mActivity.get().getApplicationContext().bindService
                    (WeatherServiceSync.makeIntent(mActivity.get()),
                            mServiceConnectionSync,
                            Context.BIND_AUTO_CREATE);

        if (mServiceConnectionAsync.getInterface() == null)
            mActivity.get().getApplicationContext().bindService
                    (WeatherServiceAsync.makeIntent(mActivity.get()),
                            mServiceConnectionAsync,
                            Context.BIND_AUTO_CREATE);
    }

    @Override
    public void unbindService() {
        if (mActivity.get().isChangingConfigurations())
            Log.d(TAG,
                    "just a configuration change - unbindService() not called");
        else {
            Log.d(TAG,
                    "calling unbindService()");

            // Unbind the Async Service if it is connected.
            if (mServiceConnectionAsync.getInterface() != null)
                mActivity.get().getApplicationContext().unbindService
                        (mServiceConnectionAsync);

            // Unbind the Sync Service if it is connected.
            if (mServiceConnectionSync.getInterface() != null)
                mActivity.get().getApplicationContext().unbindService
                        (mServiceConnectionSync);
        }
    }

    @Override
    public void getWeatherDataSync(final String cityOrCountry) {

        final WeatherCall weatherCall = mServiceConnectionSync.getInterface();

        if (weatherCall == null) return;

        mCityOrCountry = cityOrCountry;

        new AsyncTask<String, Void, List<WeatherData2>>() {

            @Override
            protected List<WeatherData2> doInBackground(String... params) {

                try {
                    return weatherCall.getCurrentWeather(params[0]);
                } catch (RemoteException e) {
                    e.printStackTrace();
                }

                return null;
            }

            @Override
            protected void onPostExecute(List<WeatherData2> weatherDataList) {
                handleServiceResult(weatherDataList);
            }
        }.execute(cityOrCountry);
    }

    @Override
    public void getWeatherDataAsync(final String cityOrCountry) {
        WeatherRequest weatherRequest = mServiceConnectionAsync.getInterface();

        if (weatherRequest == null) return;

        mCityOrCountry = cityOrCountry;

        try {
            weatherRequest.getCurrentWeather(cityOrCountry, mWeatherResults);
        } catch (RemoteException e) {
            e.printStackTrace();
            Utils.showToast(mActivity.get(), "An error occurred while trying to get weather info for " + mCityOrCountry);
        }
    }

    @Override
    public void onConfigurationChange(MainActivity activity) {
        Log.d(TAG,
                "onConfigurationChange() called");

        // Reset the mActivity WeakReference.
        mActivity = new WeakReference<>(activity);
    }

    private void handleServiceResult(List<WeatherData2> weatherDataResult){
        if (weatherDataResult != null) {
            if (weatherDataResult.size() > 0) {
                mActivity.get().showWeatherData(weatherDataResult.get(0));
            } else {
                Utils.showToast(mActivity.get(), "Weather info is not available for " + mCityOrCountry);
            }
        } else {
            Utils.showToast(mActivity.get(), "An error occurred while trying to get weather info for " + mCityOrCountry);
        }
    }
}
