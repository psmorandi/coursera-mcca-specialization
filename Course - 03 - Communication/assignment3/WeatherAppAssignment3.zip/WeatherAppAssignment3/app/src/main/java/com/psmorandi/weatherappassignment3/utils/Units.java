package com.psmorandi.weatherappassignment3.utils;

/**
 * @author Paulo (02/06/2015).
 */
public enum Units {
    METRIC,
    IMPERIAL,
    KELVIN;

    public static String getQueryParameterFrom(Units unit){
        switch (unit){
            case IMPERIAL: return "imperial";
            case KELVIN: return "kelvin";
            case METRIC: return "metric";
        }

        return "";
    }
}
