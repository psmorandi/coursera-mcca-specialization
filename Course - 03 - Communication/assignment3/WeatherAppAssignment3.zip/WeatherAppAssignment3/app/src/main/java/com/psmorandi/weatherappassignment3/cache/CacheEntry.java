package com.psmorandi.weatherappassignment3.cache;

import com.psmorandi.weatherappassignment3.aidl.WeatherData2;

import java.util.Date;
import java.util.List;

/**
 * @author Paulo (02/06/2015).
 */
public class CacheEntry {
    private List<WeatherData2> weatherDataCache;
    /**
     * Time to live of the weather data (in seconds)
     */
    private int ttl;
    private Date lastUpdate;

    public List<WeatherData2> getWeatherDataCache() {
        return weatherDataCache;
    }

    public void setWeatherDataCache(List<WeatherData2> weatherDataCache) {
        this.weatherDataCache = weatherDataCache;
    }

    public int getTtl() {
        return ttl;
    }

    public void setTtl(int ttl) {
        this.ttl = ttl;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

}
