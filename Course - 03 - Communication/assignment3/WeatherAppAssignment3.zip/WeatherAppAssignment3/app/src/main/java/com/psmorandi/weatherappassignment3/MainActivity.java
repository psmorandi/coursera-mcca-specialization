package com.psmorandi.weatherappassignment3;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import com.psmorandi.weatherappassignment3.aidl.WeatherData2;
import com.psmorandi.weatherappassignment3.operations.WeatherServicesOps;
import com.psmorandi.weatherappassignment3.operations.WeatherServicesOpsImpl;
import com.psmorandi.weatherappassignment3.utils.RetainedFragmentManager;


public class MainActivity extends LifecycleLoggingActivity {

    /**
     * Used to retain the WeatherServicesOps state between runtime configuration
     * changes.
     */
    protected final RetainedFragmentManager mRetainedFragmentManager =
            new RetainedFragmentManager(this.getFragmentManager(),
                    TAG);

    /**
     * Provides weather-related operations
     */
    private WeatherServicesOps mWeatherServicesOps;

    /**
     * City or country provided by the user.
     */
    private EditText mCityOrCountryView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Store the EditText that holds the city or country.
        mCityOrCountryView = (EditText) findViewById(R.id.city_country_edt);

        // Handle any configuration change.
        handleConfigurationChanges();
    }

    public void getWeatherSyncOnClick(View v) {
        final String cityOrCountry = mCityOrCountryView.getText().toString();
        mWeatherServicesOps.getWeatherDataSync(cityOrCountry);
    }

    public void getWeatherAsyncOnClick(View v) {
        final String cityOrCountry = mCityOrCountryView.getText().toString();
        mWeatherServicesOps.getWeatherDataAsync(cityOrCountry);
    }

    /**
     * Hook method called by Android when this Activity is
     * destroyed.
     */
    @Override
    protected void onDestroy() {
        // Unbind from the Service.
        mWeatherServicesOps.unbindService();

        // Always call super class for necessary operations when an
        // Activity is destroyed.
        super.onDestroy();
    }

    /**
     * Handle hardware reconfigurations, such as rotating the display.
     */
    protected void handleConfigurationChanges() {
        // If this method returns true then this is the first time the
        // Activity has been created.
        if (mRetainedFragmentManager.firstTimeIn()) {
            Log.d(TAG, "First time onCreate() call");
            initializeWeatherServiceOps();
        } else {
            // The RetainedFragmentManager was previously initialized,
            // which means that a runtime configuration change
            // occurred.
            Log.d(TAG, "Second or subsequent onCreate() call");

            // Obtain the WeatherServicesOps object from the
            // RetainedFragmentManager.
            mWeatherServicesOps = mRetainedFragmentManager.get("WEATHER_OPS_STATE");

            // This check shouldn't be necessary under normal
            // circumtances, but it's better to lose state than to
            // crash!
            if (mWeatherServicesOps == null) {
                initializeWeatherServiceOps();
            } else {
                // Inform it that the runtime configuration change has
                // completed.
                mWeatherServicesOps.onConfigurationChange(this);
            }
        }
    }

    private void initializeWeatherServiceOps() {
        // Create the WeatherServicesOps object one time.
        mWeatherServicesOps = new WeatherServicesOpsImpl(this);

        // Store the WeatherServicesOps into the RetainedFragmentManager.
        mRetainedFragmentManager.put("ACRONYM_OPS_STATE", mWeatherServicesOps);

        // Initiate the service binding protocol.
        mWeatherServicesOps.bindService();
    }

    public void showWeatherData(WeatherData2 weatherData){
        Intent intent = new Intent(this, WeatherResultActivity.class);
        intent.putExtra(WeatherResultActivity.WEATHER_DATA_EXTRA, weatherData);

        startActivity(intent);
    }
}
