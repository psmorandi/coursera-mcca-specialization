package com.psmorandi.weatherappassignment3.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import com.psmorandi.weatherappassignment3.aidl.WeatherData2;
import com.psmorandi.weatherappassignment3.jsonweather.JsonWeather;
import com.psmorandi.weatherappassignment3.jsonweather.Main;
import com.psmorandi.weatherappassignment3.jsonweather.Sys;
import com.psmorandi.weatherappassignment3.jsonweather.Weather;
import com.psmorandi.weatherappassignment3.jsonweather.WeatherJSONParser;
import com.psmorandi.weatherappassignment3.jsonweather.Wind;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/**
 * @class AcronymDownloadUtils
 * @brief Handles the actual downloading of Acronym information from
 * the Acronym web service.
 */
public class Utils {
    /**
     * Logging tag used by the debugger.
     */
    private final static String TAG = Utils.class.getCanonicalName();

    /**
     * URL to the Open Weather web service.
     */
    private final static String sOpen_Weather_API_URL =
            "http://api.openweathermap.org/data/2.5/weather?q=%s&units=%s";

    /**
     * URL to the Open Weather web service.
     */
    private final static String sOpen_Weather_IMAGE_URL =
            "http://openweathermap.org/img/w/%s.png";

    /**
     * Ensure this class is only used as a utility.
     */
    private Utils() {
        throw new AssertionError();
    }

    /**
     * Obtain the Weather information.
     *
     * @return The information that responds to your current weather search.
     */
    public static List<WeatherData2> getResults(final String cityOrCountry, Units unitsFormat) {

        List<JsonWeather> jsonWeatherList = null;

        try {
            // Create the full URL.
            String urlString = String.format(sOpen_Weather_API_URL, URLEncoder.encode(cityOrCountry, "UTF-8"),
                    Units.getQueryParameterFrom(unitsFormat));

            final URL url = new URL(urlString);

            // Opens a connection to the Open Weather Service.
            HttpURLConnection urlConnection =
                    (HttpURLConnection) url.openConnection();

            // Sends the GET request and reads the Json results.
            try (InputStream in =
                         new BufferedInputStream(urlConnection.getInputStream())) {
                // Create the parser.
                final WeatherJSONParser parser =
                        new WeatherJSONParser();

                // Parse the Json results and create weather list data
                // objects.
                jsonWeatherList = parser.parseJsonStream(in);
            } finally {
                urlConnection.disconnect();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // See if we parsed any valid data.
        if (jsonWeatherList != null && jsonWeatherList.size() > 0) {
            JsonWeather jsonWeather = jsonWeatherList.get(0);
            if (jsonWeather.getCod() == 200) {

                Weather currentWeather = jsonWeather.getWeather().get(0);
                Main main = jsonWeather.getMain();
                Wind wind = jsonWeather.getWind();
                Sys sys = jsonWeather.getSys();

                WeatherData2 data = new WeatherData2(jsonWeather.getName(),
                        sys.getCountry(),
                        currentWeather.getMain(),
                        currentWeather.getDescription(),
                        currentWeather.getIcon(),
                        wind.getSpeed(),
                        wind.getDeg(),
                        main.getTemp(),
                        main.getTempMin(),
                        main.getTempMax(),
                        main.getHumidity(),
                        sys.getSunrise(),
                        sys.getSunset());

                String iconCode = currentWeather.getIcon();

                if (!TextUtils.isEmpty(currentWeather.getIcon())) {
                    data.setIconData(getWeatherImage(iconCode));
                }

                List<WeatherData2> weatherDataList = new ArrayList<>();
                weatherDataList.add(data);
                return weatherDataList;
            }

            Log.i(TAG, "Error from API: code:" + jsonWeather.getCod() + ", message: " + jsonWeather.getMessage());
            return null;
        } else
            return null;
    }

    /**
     * Show a toast message.
     */
    public static void showToast(Context context,
                                 String message) {
        Toast.makeText(context,
                message,
                Toast.LENGTH_SHORT).show();
    }

    private static Bitmap getWeatherImage(String code) {
        Bitmap bitmap = null;
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = false;
        try {
            bitmap = BitmapFactory.decodeStream((InputStream) new URL(String.format(sOpen_Weather_IMAGE_URL, code)).getContent(), null, options);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return bitmap;
    }
}
