package com.psmorandi.weatherappassignment3.operations;

import com.psmorandi.weatherappassignment3.MainActivity;

/**
 * @author Paulo (01/06/2015).
 */
public interface WeatherServicesOps {
    /**
     * Initiate the service binding protocol.
     */
    void bindService();

    /**
     * Initiate the service unbinding protocol.
     */
    void unbindService();

    /**
     * Initiate the synchronous get of weather data when the user press the button "Get Weather Sync".
     *
     * @param cityOrCountry The city or country to get the weather data from.
     */
    void getWeatherDataSync(String cityOrCountry);

    /**
     * Initiate the asynchronous get of weather data when the user press the button "Get Weather Async".
     *
     * @param cityOrCountry The city or country to get the weather data from.
     */
    void getWeatherDataAsync(String cityOrCountry);

    /**
     * Called after a runtime configuration change occurs to finish
     * the initialization steps.
     */
    void onConfigurationChange(MainActivity activity);
}
