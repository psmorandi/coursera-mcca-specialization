package com.psmorandi.weatherappassignment3.jsonweather;

import android.util.JsonReader;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * Parses the Json weather data returned from the Weather Services API
 * and returns a List of JsonWeather objects that contain this data.
 */
public class WeatherJSONParser {
    /**
     * Used for logging purposes.
     */
    private final String TAG =
            this.getClass().getCanonicalName();

    /**
     * Parse the @a inputStream and convert it into a List of JsonWeather
     * objects.
     */
    public List<JsonWeather> parseJsonStream(InputStream inputStream)
            throws IOException {
        // Create a JsonReader for the inputStream.
        try (JsonReader reader =
                     new JsonReader(new InputStreamReader(inputStream,
                             "UTF-8"))) {
            Log.d(TAG, "Parsing the results returned as an array");

            List<JsonWeather> returnList = new ArrayList<>();
            returnList.add(parseJsonWeather(reader));

            return returnList;
        }
    }
    
    /**
     * Parse a Json stream and return a JsonWeather object.
     */
    public JsonWeather parseJsonWeather(JsonReader reader)
            throws IOException {
        reader.beginObject();

        JsonWeather jsonWeather = new JsonWeather();

        Log.d(TAG, "Parsing JsonWeather....");

        try {
            while (reader.hasNext()) {
                String name = reader.nextName();
                switch (name) {
                    case JsonWeather.cod_JSON:
                        //Log.d(TAG, "cod");
                        jsonWeather.setCod(reader.nextLong());
                        break;
                    case JsonWeather.base_JSON:
                        //Log.d(TAG, "base");
                        jsonWeather.setBase(reader.nextString());
                        break;
                    case JsonWeather.dt_JSON:
                        //Log.d(TAG, "dt");
                        jsonWeather.setDt(reader.nextLong());
                        break;
                    case JsonWeather.id_JSON:
                        //Log.d(TAG, "id");
                        jsonWeather.setId(reader.nextLong());
                        break;
                    case JsonWeather.main_JSON:
                        //Log.d(TAG, "main");
                        jsonWeather.setMain(parseMain(reader));
                        break;
                    case JsonWeather.name_JSON:
                        //Log.d(TAG, "name");
                        jsonWeather.setName(reader.nextString());
                        break;
                    case JsonWeather.sys_JSON:
                        //Log.d(TAG, "sys");
                        jsonWeather.setSys(parseSys(reader));
                        break;
                    case JsonWeather.weather_JSON:
                        //Log.d(TAG, "weather");
                        jsonWeather.setWeather(parseWeathers(reader));
                        break;
                    case JsonWeather.wind_JSON:
                        //Log.d(TAG, "wind");
                        jsonWeather.setWind(parseWind(reader));
                        break;
                    case JsonWeather.message_JSON:
                        //Log.d(TAG, "message");
                        jsonWeather.setMessage(reader.nextString());
                        break;
                    default:
                        reader.skipValue();
                        //Log.d(TAG, "weird problem with " + name + " field");
                        break;
                }
            }
        } finally {
            reader.endObject();
        }

        return jsonWeather;
    }

    /**
     * Parse a Json stream and return a List of Weather objects.
     */
    public List<Weather> parseWeathers(JsonReader reader) throws IOException {

        Log.d(TAG, "Parsing list of weathers....");

        reader.beginArray();

        try {
            List<Weather> weathers = new ArrayList<>();

            while (reader.hasNext())
                weathers.add(parseWeather(reader));

            return weathers;
        } finally {
            reader.endArray();
        }
    }

    /**
     * Parse a Json stream and return a Weather object.
     */
    public Weather parseWeather(JsonReader reader) throws IOException {

        Log.d(TAG, "Parsing weather....");

        reader.beginObject();

        Weather weather = new Weather();

        try {

            while (reader.hasNext()) {
                String name = reader.nextName();
                switch (name) {
                    case Weather.description_JSON:
                        //Log.d(TAG, "description");
                        weather.setDescription(reader.nextString());
                        break;
                    case Weather.icon_JSON:
                        //Log.d(TAG, "icon");
                        weather.setIcon(reader.nextString());
                        break;
                    case Weather.id_JSON:
                        //Log.d(TAG, "id");
                        weather.setId(reader.nextLong());
                        break;
                    case Weather.main_JSON:
                        //Log.d(TAG, "main");
                        weather.setMain(reader.nextString());
                        break;
                    default:
                        reader.skipValue();
                        //Log.d(TAG, "weird problem with " + name + " field");
                        break;
                }
            }

            return weather;
        } finally {
            reader.endObject();
        }
    }

    /**
     * Parse a Json stream and return a Main Object.
     */
    public Main parseMain(JsonReader reader)
            throws IOException {
        Log.d(TAG, "Parsing main....");

        Main main = new Main();

        reader.beginObject();
        try {
            while (reader.hasNext()) {
                String name = reader.nextName();
                switch (name) {
                    case Main.grndLevel_JSON:
                        //Log.d(TAG, "grndlevel");
                        main.setGrndLevel(reader.nextDouble());
                        break;
                    case Main.humidity_JSON:
                        //Log.d(TAG, "humidity");
                        main.setHumidity(reader.nextLong());
                        break;
                    case Main.pressure_JSON:
                        //Log.d(TAG, "pressure");
                        main.setPressure(reader.nextDouble());
                        break;
                    case Main.seaLevel_JSON:
                        //Log.d(TAG, "seaLevel");
                        main.setSeaLevel(reader.nextDouble());
                        break;
                    case Main.temp_JSON:
                        //Log.d(TAG, "temp");
                        main.setTemp(reader.nextDouble());
                        break;
                    case Main.tempMax_JSON:
                        //Log.d(TAG, "tempMax");
                        main.setTempMax(reader.nextDouble());
                        break;
                    case Main.tempMin_JSON:
                        //Log.d(TAG, "tempMin");
                        main.setTempMin(reader.nextDouble());
                        break;
                    default:
                        reader.skipValue();
                        //Log.d(TAG, "weird problem with " + name + " field");
                        break;
                }
            }
            return main;
        } finally {
            reader.endObject();
        }
    }

    /**
     * Parse a Json stream and return a Wind Object.
     */
    public Wind parseWind(JsonReader reader) throws IOException {
        Log.d(TAG, "Parsing Wind....");

        Wind wind = new Wind();

        reader.beginObject();
        try {
            while (reader.hasNext()) {
                String name = reader.nextName();
                switch (name) {
                    case Wind.deg_JSON:
                        //Log.d(TAG, "deg");
                        wind.setDeg(reader.nextDouble());
                        break;
                    case Wind.speed_JSON:
                        //Log.d(TAG, "speed");
                        wind.setSpeed(reader.nextDouble());
                        break;
                    default:
                        reader.skipValue();
                        //Log.d(TAG, "weird problem with " + name + " field");
                        break;
                }
            }
            return wind;
        } finally {
            reader.endObject();
        }
    }

    /**
     * Parse a Json stream and return a Sys Object.
     */
    public Sys parseSys(JsonReader reader) throws IOException {
        Log.d(TAG, "Parsing sys....");

        Sys sys = new Sys();

        reader.beginObject();
        try {
            while (reader.hasNext()) {
                String name = reader.nextName();
                switch (name) {
                    case Sys.country_JSON:
                        //Log.d(TAG, "country");
                        sys.setCountry(reader.nextString());
                        break;
                    case Sys.message_JSON:
                        //Log.d(TAG, "message");
                        sys.setMessage(reader.nextDouble());
                        break;
                    case Sys.sunrise_JSON:
                        //Log.d(TAG, "sunrise");
                        sys.setSunrise(reader.nextLong());
                        break;
                    case Sys.sunset_JSON:
                        //Log.d(TAG, "sunset");
                        sys.setSunset(reader.nextLong());
                        break;
                    default:
                        reader.skipValue();
                        //Log.d(TAG, "weird problem with " + name + " field");
                        break;
                }
            }
            return sys;
        } finally {
            reader.endObject();
        }
    }
}