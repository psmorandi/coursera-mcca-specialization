package com.psmorandi.weatherappassignment3;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.psmorandi.weatherappassignment3.aidl.WeatherData2;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * @author Paulo (02/06/2015).
 */
public class WeatherResultActivity extends LifecycleLoggingActivity {

    public static final String WEATHER_DATA_EXTRA = "br.com.psmorandi.WEATHER_DATA";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_weather_result);

        WeatherData2 weatherData = getIntent().getParcelableExtra(WEATHER_DATA_EXTRA);

        String cityText = String.format("%s, %s", weatherData.getName(), weatherData.getCountry());

        TextView textView = (TextView) findViewById(R.id.cityText);
        textView.setText(cityText);

        textView = (TextView) findViewById(R.id.condDescr);
        textView.setText(weatherData.getCurrentConditionDescription());

        ImageView imageView = (ImageView) findViewById(R.id.condIcon);
        imageView.setImageBitmap(weatherData.getIconData());

        String tempText = "%s \u00b0C";

        textView = (TextView) findViewById(R.id.temp);
        textView.setText(String.format(tempText, weatherData.getTemp()));

        textView = (TextView) findViewById(R.id.tempMax);
        textView.setText(String.format(tempText, weatherData.getTempMax()));

        textView = (TextView) findViewById(R.id.tempMin);
        textView.setText(String.format(tempText, weatherData.getTempMin()));

        textView = (TextView) findViewById(R.id.hum);
        textView.setText(Long.toString(weatherData.getHumidity()) + "%");

        textView = (TextView) findViewById(R.id.windSpeed);
        textView.setText(Double.toString(weatherData.getSpeed()) + " m/s");

        textView = (TextView) findViewById(R.id.windDeg);
        textView.setText(Double.toString(weatherData.getDeg()) + "\u00b0");

        textView = (TextView) findViewById(R.id.sunrise);
        textView.setText(getFormattedSunTimes(weatherData.getSunrise()));

        textView = (TextView) findViewById(R.id.sunset);
        textView.setText(getFormattedSunTimes(weatherData.getSunset()));
    }

    private String getFormattedSunTimes(long unixTime) {
        Date time = new Date(unixTime * 1000); //needs to be in milliseconds
        SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm", Locale.getDefault());

        return dateFormat.format(time);
    }
}
