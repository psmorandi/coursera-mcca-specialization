package com.psmorandi.weatherappassignment3.cache;

import com.psmorandi.weatherappassignment3.aidl.WeatherData2;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * @author Paulo (02/06/2015).
 */
public class WeatherCache {

    protected static final HashMap<String, CacheEntry> weatherCache = new HashMap<>();

    public static List<WeatherData2> get(String cityOrCountry) {
        synchronized (weatherCache) {

            //not the best approach, but it's what we have for today...
            clearExpiredEntries();

            if (weatherCache.containsKey(cityOrCountry)) {
                //cache hit..
                return weatherCache.get(cityOrCountry).getWeatherDataCache();
            }

            //Cache miss..
            return null;
        }
    }

    public static void put(String cityOrCountry, List<WeatherData2> dataToCache) {
        synchronized (weatherCache) {

            //again... not the best approach, but it's what we have for today...
            clearExpiredEntries();

            CacheEntry cache;

            if (weatherCache.containsKey(cityOrCountry)) {
                //already in cache.. so get it to update it..
                cache = weatherCache.get(cityOrCountry);
            } else {
                cache = new CacheEntry();
                //live for just 10 seconds
                cache.setTtl(10);
            }

            cache.setLastUpdate(new Date());
            cache.setWeatherDataCache(dataToCache);

            weatherCache.put(cityOrCountry, cache);
        }
    }

    private static void clearExpiredEntries() {
        for (String key : weatherCache.keySet()) {
            if (isExpired(weatherCache.get(key))) {
                weatherCache.remove(key);
            }
        }
    }

    private static boolean isExpired(CacheEntry cacheEntry) {
        Calendar now = Calendar.getInstance();
        now.setTime(new Date());

        Calendar cacheEntryDate = Calendar.getInstance();
        cacheEntryDate.setTime(cacheEntry.getLastUpdate());
        cacheEntryDate.add(Calendar.SECOND, cacheEntry.getTtl());

        return now.compareTo(cacheEntryDate) > 0;
    }
}