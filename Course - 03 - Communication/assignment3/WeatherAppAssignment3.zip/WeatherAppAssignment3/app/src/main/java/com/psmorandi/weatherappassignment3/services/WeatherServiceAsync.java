package com.psmorandi.weatherappassignment3.services;

import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

import com.psmorandi.weatherappassignment3.aidl.WeatherData2;
import com.psmorandi.weatherappassignment3.aidl.WeatherRequest;
import com.psmorandi.weatherappassignment3.aidl.WeatherResults;
import com.psmorandi.weatherappassignment3.cache.WeatherCache;
import com.psmorandi.weatherappassignment3.utils.Units;
import com.psmorandi.weatherappassignment3.utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Paulo (24/05/2015).
 */
public class WeatherServiceAsync extends LifecycleLoggingService {

    WeatherRequest.Stub mWeatherRequest = new WeatherRequest.Stub() {
        @Override
        public void getCurrentWeather(String cityOrCountry, WeatherResults callback) throws RemoteException {

            List<WeatherData2> serviceResult = WeatherCache.get(cityOrCountry);

            if (serviceResult == null) {
                Log.d(TAG, "Cache miss, calling Weather Web API...");
                serviceResult = Utils.getResults(cityOrCountry, Units.METRIC);

                if (serviceResult == null) {
                    serviceResult = new ArrayList<>(0);
                } else {
                    WeatherCache.put(cityOrCountry, serviceResult);
                }
            } else {
                Log.d(TAG, "No need to call Weather Web API, send results back from cache.");
            }

            if (callback != null) {
                callback.sendResults(serviceResult);
            }
        }
    };

    public static Intent makeIntent(Context context) {
        return new Intent(context, WeatherServiceAsync.class);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mWeatherRequest;
    }
}
