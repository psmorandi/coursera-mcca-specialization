package com.psmorandi.weatherappassignment3.services;

import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

import com.psmorandi.weatherappassignment3.aidl.WeatherCall;
import com.psmorandi.weatherappassignment3.aidl.WeatherData2;
import com.psmorandi.weatherappassignment3.cache.WeatherCache;
import com.psmorandi.weatherappassignment3.utils.Units;
import com.psmorandi.weatherappassignment3.utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Paulo (24/05/2015).
 */
public class WeatherServiceSync extends LifecycleLoggingService {

    private WeatherCall.Stub mWeatherCall = new WeatherCall.Stub() {
        @Override
        public List<WeatherData2> getCurrentWeather(String cityOrCountry) throws RemoteException {
            List<WeatherData2> cachedData = WeatherCache.get(cityOrCountry);
            if(cachedData == null) {
                Log.d(TAG,"Cache miss, calling Weather Web API...");
                List<WeatherData2> weatherDataList = Utils.getResults(cityOrCountry, Units.METRIC);

                if(weatherDataList == null) return new ArrayList<>(0);

                WeatherCache.put(cityOrCountry, weatherDataList);

                return  weatherDataList;
            }

            Log.d(TAG,"No need to call Weather Web API, return data from cache.");
            return cachedData;
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return mWeatherCall;
    }

    public static Intent makeIntent(Context context) {
        return new Intent(context, WeatherServiceSync.class);
    }
}