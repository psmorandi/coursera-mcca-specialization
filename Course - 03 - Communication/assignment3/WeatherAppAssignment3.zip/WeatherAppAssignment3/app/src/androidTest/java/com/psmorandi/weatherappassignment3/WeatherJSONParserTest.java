package com.psmorandi.weatherappassignment3;

import android.test.AndroidTestCase;

import com.psmorandi.weatherappassignment3.jsonweather.JsonWeather;
import com.psmorandi.weatherappassignment3.jsonweather.WeatherJSONParser;

import junit.framework.Assert;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * @author Paulo (31/05/2015).
 */
public class WeatherJSONParserTest extends AndroidTestCase {

    WeatherJSONParser weatherJSONParser;

    @Override
    protected void setUp() throws Exception {
        super.setUp();
        weatherJSONParser = new WeatherJSONParser();
    }

    public void testParseJsonWeather() throws Exception {
        String json = "{\"coord\":{\"lon\":-86.79,\"lat\":36.17},\"sys\":{\"message\":0.0125,\"country\":\"US\",\"sunrise\":1433068285,\"sunset\":1433120327,\"id\":37686,\"type\":3},\"weather\":[{\"id\":501,\"main\":\"Rain\",\"description\":\"moderate rain\",\"icon\":\"10d\"}],\"base\":\"stations\",\"main\":{\"temp\":295.26,\"temp_min\":294.26,\"temp_max\":295.93,\"pressure\":1016,\"humidity\":88},\"wind\":{\"speed\":2.06,\"deg\":120},\"rain\":{\"1h\":1.78},\"clouds\":{\"all\":68},\"dt\":1433110897,\"id\":4644585,\"name\":\"Nashville\",\"cod\":200}";

        InputStream stream = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));

        List<JsonWeather> jsonWeatherList = weatherJSONParser.parseJsonStream(stream);

        Assert.assertNotNull(jsonWeatherList);
        Assert.assertTrue(jsonWeatherList.size() > 0);

    }
}
